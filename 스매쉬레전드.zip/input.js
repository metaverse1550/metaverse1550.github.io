// ===== input.js =====
// 키보드/모바일 조이스틱·터치패드 입력 처리 + 전체화면 토글 + 메가샷 트리거
// game, SoundEngine 등 전역 객체를 "사용"은 하지만, input.js 자체는 게임 규칙을 모름

const keys = {
    w: false, a: false, s: false, d: false, r: false,
    ArrowUp: false, ArrowDown: false, ArrowLeft: false, ArrowRight: false,
    '1': false, '2': false, '3': false 
};
const keyJustPressed = {}; 
const keyPressTime = {}; 

let emoteTimeoutId = null;
let pendingActionKey = null;

window.addEventListener('keydown', (e) => {
    let k_lower = e.key.toLowerCase();
    let k_exact = e.key;

    let targetKey = null;
    if (keys.hasOwnProperty(k_lower)) targetKey = k_lower;
    else if (keys.hasOwnProperty(k_exact)) targetKey = k_exact;

    if (targetKey) {
        if (!keys[targetKey]) {
            keyJustPressed[targetKey] = true;
            keyPressTime[targetKey] = Date.now(); 
        }
        keys[targetKey] = true;
    }

    // 1, 2, 3 키 입력 처리 (티배깅 vs 감정표현 이모티콘 완벽 분리)
    if (['1', '2', '3'].includes(e.key)) {
        let myChar = null;
        if (typeof game !== 'undefined' && typeof networkRole !== 'undefined') {
            myChar = (networkRole === 'host') ? game.p1 : game.p2;
        }
        
        if (myChar && game.state !== STATE.SERVE && !myChar.isSwinging && myChar.hitCooldown <= 0) {
            if (pendingActionKey === null) {
                // 첫 번째 키가 눌렸을 때 0.15초(150ms) 대기
                pendingActionKey = e.key;
                emoteTimeoutId = setTimeout(() => {
                    // 0.15초 동안 다른 키가 안 눌리면 -> 단독 티배깅(몸통 애니메이션) 발동
                    // 주의: 티배깅 애니메이션은 activeEmote 숫자로 작동합니다!
                    let emoteNum = parseInt(pendingActionKey);
                    myChar.activeEmote = emoteNum;
                    myChar.emoteTimer = 0;
                    if (typeof broadcastData === 'function') {
                        broadcastData('player_emote', { emote: emoteNum });
                    }
                    pendingActionKey = null;
                }, 150);
            } else if (pendingActionKey !== e.key) {
                // 0.15초 안에 두 번째 다른 키가 눌리면 -> 타이머 취소하고 감정표현(말풍선) 발동
                clearTimeout(emoteTimeoutId);
                
                // 12, 23, 13 처럼 키 조합 생성 (정렬해서 '2'+'1'도 '12'로 통일)
                let combo = [pendingActionKey, e.key].sort().join('');
                let bubbleType = 1;
                
                if (combo === '12') bubbleType = 1;
                else if (combo === '23') bubbleType = 2;
                else if (combo === '13') bubbleType = 3;
                
                // 말풍선 생성 및 전송
                game.spawnEmotion(myChar, bubbleType);
                if (typeof broadcastData === 'function') {
                    broadcastData('player_emotion', { type: bubbleType });
                }
                
                pendingActionKey = null;
            }
        }
    }

    if (k_lower === 'r') {
        if (typeof triggerMegaShot === 'function') triggerMegaShot();
    }
});

window.addEventListener('keyup', (e) => { 
    let k_lower = e.key.toLowerCase();
    let k_exact = e.key;

    if (keys.hasOwnProperty(k_lower)) keys[k_lower] = false;
    if (keys.hasOwnProperty(k_exact)) keys[k_exact] = false;
    
    if (k_lower === 'w') {
        let myChar = (networkRole === 'host') ? game.p1 : game.p2;
        if (myChar) myChar.stopJump();
    }
});

function isJustPressed(key) {
    if (keyJustPressed[key]) { keyJustPressed[key] = false; return true; }
    return false;
}


function toggleFullscreen() {
    let elem = document.getElementById('game-container');
    if (!document.fullscreenElement && !document.webkitFullscreenElement && !document.msFullscreenElement) {
        if (elem.requestFullscreen) elem.requestFullscreen();
        else if (elem.webkitRequestFullscreen) elem.webkitFullscreen(); 
        else if (elem.msRequestFullscreen) elem.msRequestFullscreen();
        document.getElementById('fullscreen-btn').innerText = "[ ⛶ 창모드 ]";
    } else {
        if (document.exitFullscreen) document.exitFullscreen();
        else if (document.webkitExitFullscreen) document.webkitExitFullscreen();
        else if (document.msExitFullscreen) document.msExitFullscreen();
        document.getElementById('fullscreen-btn').innerText = "[ ⛶ 전체화면 ]";
    }
}


function setupMobileJoystickAndPad() {
    const joyContainer = document.getElementById('joy-container');
    const joyHandle = document.getElementById('joy-handle');
    if (!joyContainer || !joyHandle) return;

    let isActive = false;
    let startX = 0;
    let maxDistance = 45; 

    const bindTouchAction = (elemId, keyName) => {
        let el = document.getElementById(elemId);
        if(!el) return;
        el.addEventListener('touchstart', (e) => {
            e.preventDefault();
            if(!keys[keyName]) {
                keyJustPressed[keyName] = true;
                keyPressTime[keyName] = Date.now();
            }
            keys[keyName] = true;
        }, {passive: false});
        
        el.addEventListener('touchend', (e) => {
            e.preventDefault();
            keys[keyName] = false;
            
            if (keyName === 'w') {
                let myChar = (networkRole === 'host') ? game.p1 : game.p2;
                if (myChar) myChar.stopJump();
            }
        }, {passive: false});
    };

    bindTouchAction('touch-jump', 'w');
    bindTouchAction('touch-lob', 'ArrowUp');
    bindTouchAction('touch-smash', 'ArrowDown');
    bindTouchAction('touch-drop', 'ArrowLeft');
    bindTouchAction('touch-drive', 'ArrowRight');

    const touchMega = document.getElementById('touch-mega');
    if (touchMega) {
        touchMega.addEventListener('touchstart', (e) => {
            e.preventDefault();
            triggerMegaShot();
        }, {passive: false});
    }

    joyContainer.addEventListener('touchstart', (e) => {
        e.preventDefault();
        isActive = true;
        let touch = e.touches[0];
        let rect = joyContainer.getBoundingClientRect();
        startX = rect.left + rect.width / 2; 
    }, {passive: false});

    joyContainer.addEventListener('touchmove', (e) => {
        if (!isActive) return;
        e.preventDefault();
        let touch = e.touches[0];
        let deltaX = touch.clientX - startX;

        deltaX = Math.max(-maxDistance, Math.min(maxDistance, deltaX));
        joyHandle.style.transform = `translate(${deltaX}px, 0px)`;

        let ratio = deltaX / maxDistance;     

        if (ratio < -0.3) {
            keys.a = true; keys.d = false;
        } else if (ratio > 0.3) {
            keys.d = true; keys.a = false;
        } else {
            keys.a = false; keys.d = false;
        }
    }, {passive: false});

    const resetJoystick = (e) => {
        if (!isActive) return;
        e.preventDefault();
        isActive = false;
        joyHandle.style.transform = `translate(0px, 0px)`; 
        keys.a = false;
        keys.d = false;
    };

    joyContainer.addEventListener('touchend', resetJoystick, {passive: false});
    joyContainer.addEventListener('touchcancel', resetJoystick, {passive: false});
}
setupMobileJoystickAndPad();

function triggerMegaShot() {
    if (game.state === STATE.MENU || game.state === STATE.MATCH_OVER || game.state === STATE.SCORE_WAIT) return;
    if (game.state === STATE.SERVE) return;
    let myChar = (networkRole === 'host') ? game.p1 : game.p2;
    if (myChar.isSwinging || myChar.hitCooldown > 0) return;
    if (localMegaCooldown > 0) return;

    game.spawnParticles(myChar.x, myChar.y - 45, '#ffd700', 35);
    game.shockwaves.push(new SmashShockwave(myChar.x, myChar.y - 45, '#ffd700', 1.4));
    SoundEngine.playMegaAttemptSound();

    myChar.swing('mega');
    localMegaCooldown = 60 * 1000; 
    lastMegaTriggerTime = Date.now();

    if (networkRole === 'guest') {
        broadcastData('guest_swing_input', { type: 'mega' });
    }
}
