// ===== effects.js =====
// 시각 이펙트 클래스 모음: 파티클, 궤적, 스매시 충격파, 플로팅 텍스트, 감정 표현 버블
// 전부 렌더링 전용, 게임 판정 로직과 무관

class Particle {
    constructor(x, y, color) {
        this.x = x; this.y = y;
        this.vx = rand(-5, 5); this.vy = rand(-5, 5);
        this.life = 1.0; this.decay = rand(0.02, 0.05);
        this.color = color; this.size = rand(2, 6);
    }
    update() { this.x += this.vx; this.y += this.vy; this.life -= this.decay; }
    draw(ctx) {
        ctx.globalAlpha = this.life; ctx.fillStyle = this.color;
        ctx.beginPath(); ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2); ctx.fill();
        ctx.globalAlpha = 1.0;
    }
}

class DriftParticle {
    constructor(x, y, color, hitterDir) {
        this.x = x + rand(-15, 15);
        this.y = y + rand(-25, 25);
        this.vx = hitterDir * rand(4, 9); 
        this.vy = rand(-2.5, 0.5); 
        this.life = 1.0;
        this.decay = rand(0.015, 0.03); 
        this.color = color;
        this.size = rand(3.5, 7.5);
    }
    update() {
        this.x += this.vx;
        this.y += this.vy;
        this.vx *= 0.94;
        this.vy *= 0.94;
        this.life -= this.decay;
    }
    draw(ctx) {
        ctx.save();
        ctx.globalAlpha = this.life;
        ctx.fillStyle = this.color;
        ctx.shadowBlur = 12;
        ctx.shadowColor = this.color;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
    }
}

class SmashShockwave {
    constructor(x, y, color = '#ffffff', sizeMultiplier = 1) {
        this.x = x; this.y = y;
        this.radius = 10;
        this.maxRadius = 140 * sizeMultiplier;
        this.life = 1.0;
        this.decay = 0.045 / sizeMultiplier; 
        this.color = color;
    }
    update() {
        this.radius += (this.maxRadius - this.radius) * 0.18;
        this.life -= this.decay;
    }
    draw(ctx) {
        if (this.life <= 0) return;
        ctx.save();
        ctx.globalAlpha = this.life;
        ctx.strokeStyle = this.color;
        ctx.lineWidth = 5 * this.life; 
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
    }
}

class FloatingText {
    constructor(x, y, text, color, size = 30) {
        this.x = x; this.y = y; this.text = text; this.color = color; this.size = size;
        this.life = 1.0; this.vy = -2;
    }
    update() { this.y += this.vy; this.life -= 0.02; }
    draw(ctx) {
        ctx.save(); ctx.globalAlpha = this.life;
        ctx.font = `bold ${this.size}px 'Black Han Sans', sans-serif`;
        ctx.fillStyle = this.color; ctx.strokeStyle = 'black'; ctx.lineWidth = 4;
        
        if (networkRole === 'guest') {
            ctx.scale(-1, 1);
            ctx.strokeText(this.text, -this.x, this.y);
            ctx.fillText(this.text, -this.x, this.y);
        } else {
            ctx.strokeText(this.text, this.x, this.y);
            ctx.fillText(this.text, this.x, this.y);
        }
        ctx.restore();
    }
}

class EmotionBubble {
    constructor(owner, type) {
        this.owner = owner;
        this.type = type; 
        this.life = 1.0;
        this.x = owner.x;
        this.y = owner.y - owner.height - 15; 
        this.vy = -0.4; 
        this.bubbleW = 90;
        this.bubbleH = 80;
    }

    update() {
        this.life -= 0.012; 
        this.y += this.vy;
        this.x = this.owner.x + (this.owner.dir === 1 ? -10 : 10);
        if (this.life <= 0) this.life = 0;
    }

    draw(ctx) {
        if (this.life <= 0) return;
        ctx.save();
        ctx.globalAlpha = this.life;
        if (networkRole === 'guest') {
            ctx.translate(CW, 0);
            ctx.scale(-1, 1);
        }
        ctx.translate(this.x, this.y);
        
        let faceDir = this.owner.dir; 
        if (faceDir === 1) { ctx.scale(-1, 1); } 

        ctx.fillStyle = '#fff';
        ctx.beginPath();
        ctx.roundRect(-this.bubbleW/2, -this.bubbleH/2, this.bubbleW, this.bubbleH, 15);
        ctx.fill();
        
        ctx.beginPath();
        ctx.moveTo(10, this.bubbleH/2);
        ctx.lineTo(25, this.bubbleH/2 + 18);
        ctx.lineTo(0, this.bubbleH/2);
        ctx.fill();

        ctx.translate(0, -5); 
        if (this.type === 1) this.drawTeemoThumbsUp(ctx); 
        else if (this.type === 2) this.drawBeeEmoji(ctx);   
        else if (this.type === 3) this.drawQuestionPing(ctx); 

        ctx.restore();
    }

    drawTeemoThumbsUp(ctx) {
        ctx.save();
        ctx.translate(0, 5); 
        
        let glow = ctx.createRadialGradient(0, 0, 5, 0, 0, 40);
        glow.addColorStop(0, 'rgba(255, 255, 150, 0.8)');
        glow.addColorStop(1, 'rgba(255, 255, 150, 0)');
        ctx.fillStyle = glow;
        ctx.beginPath(); ctx.arc(0, 0, 45, 0, Math.PI*2); ctx.fill();

        ctx.fillStyle = '#c0392b';
        ctx.beginPath();
        ctx.moveTo(-20, 20); ctx.lineTo(-25, 30); ctx.lineTo(-10, 25);
        ctx.lineTo(0, 32); ctx.lineTo(10, 25); ctx.lineTo(25, 28);
        ctx.lineTo(15, 15); ctx.fill();

        ctx.fillStyle = '#e5c3a6';
        ctx.beginPath(); ctx.ellipse(-5, 0, 26, 20, 0, 0, Math.PI*2); ctx.fill();

        ctx.fillStyle = '#c89e7c';
        ctx.beginPath(); ctx.ellipse(-18, -2, 12, 10, -Math.PI/6, 0, Math.PI*2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(8, -2, 12, 10, Math.PI/6, 0, Math.PI*2); ctx.fill();

        ctx.strokeStyle = '#3e2723'; ctx.lineWidth = 3; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.arc(-18, -2, 7, Math.PI*1.1, Math.PI*1.9); ctx.stroke();
        ctx.beginPath(); ctx.arc(8, -2, 7, Math.PI*1.1, Math.PI*1.9); ctx.stroke();

        ctx.fillStyle = '#4e342e'; ctx.beginPath(); ctx.ellipse(-5, 5, 4, 2.5, 0, 0, Math.PI*2); ctx.fill();
        ctx.strokeStyle = '#4e342e'; ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(-10, 10); ctx.quadraticCurveTo(-5, 15, 0, 10); ctx.stroke();

        ctx.fillStyle = '#27ae60';
        ctx.beginPath();
        ctx.moveTo(-35, -5); ctx.quadraticCurveTo(-20, -25, -5, -15);
        ctx.quadraticCurveTo(10, -25, 25, -5);
        ctx.quadraticCurveTo(-5, -10, -35, -5); ctx.fill();

        ctx.fillStyle = '#e74c3c';
        ctx.beginPath(); ctx.roundRect(-22, -26, 14, 8, 3); ctx.fill();
        ctx.beginPath(); ctx.roundRect(-2, -26, 14, 8, 3); ctx.fill();
        ctx.strokeStyle = '#c0392b'; ctx.lineWidth = 2;
        ctx.strokeRect(-22, -26, 14, 8); ctx.strokeRect(-2, -26, 14, 8);

        ctx.fillStyle = '#2ecc71';
        ctx.strokeStyle = '#27ae60'; ctx.lineWidth = 2;
        ctx.save();
        ctx.translate(22, 15);
        ctx.rotate(-Math.PI/8);
        ctx.beginPath(); ctx.ellipse(0, 0, 12, 15, 0, 0, Math.PI*2); ctx.fill(); ctx.stroke(); 
        ctx.beginPath(); ctx.moveTo(-5, -10); ctx.quadraticCurveTo(-15, -25, 0, -25); 
        ctx.quadraticCurveTo(8, -25, 5, -10); ctx.fill(); ctx.stroke(); 
        ctx.restore();

        ctx.restore();
    }

    drawBeeEmoji(ctx) {
        ctx.save();
        ctx.translate(0, 5);

        let bodyGrad = ctx.createRadialGradient(-5, -5, 5, 0, 0, 25);
        bodyGrad.addColorStop(0, '#fff200'); bodyGrad.addColorStop(1, '#f39c12');
        ctx.fillStyle = bodyGrad;
        ctx.beginPath(); ctx.ellipse(0, 0, 30, 22, -Math.PI/12, 0, Math.PI*2); ctx.fill();

        ctx.strokeStyle = '#5d4037'; ctx.lineWidth = 8; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.moveTo(10, -20); ctx.quadraticCurveTo(20, 0, 10, 20); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(22, -15); ctx.quadraticCurveTo(30, 0, 22, 15); ctx.stroke();

        ctx.fillStyle = '#111';
        ctx.beginPath(); ctx.moveTo(28, 5); ctx.lineTo(45, 10); ctx.lineTo(26, 15); ctx.fill();

        ctx.fillStyle = 'rgba(178, 235, 242, 0.8)';
        ctx.strokeStyle = '#80deea'; ctx.lineWidth = 2;
        ctx.save(); ctx.translate(-5, -15); ctx.rotate(-Math.PI/6);
        ctx.beginPath(); ctx.ellipse(0, -15, 10, 20, 0, 0, Math.PI*2); ctx.fill(); ctx.stroke();
        ctx.restore();
        ctx.save(); ctx.translate(15, -12); ctx.rotate(Math.PI/6);
        ctx.beginPath(); ctx.ellipse(0, -15, 10, 20, 0, 0, Math.PI*2); ctx.fill(); ctx.stroke();
        ctx.restore();

        ctx.fillStyle = '#111';
        ctx.beginPath(); ctx.ellipse(-15, -2, 6, 8, -Math.PI/8, 0, Math.PI*2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(2, -2, 6, 8, Math.PI/8, 0, Math.PI*2); ctx.fill();
        
        ctx.fillStyle = '#fff';
        ctx.beginPath(); ctx.arc(-16, -5, 3, 0, Math.PI*2); ctx.fill();
        ctx.beginPath(); ctx.arc(1, -5, 3, 0, Math.PI*2); ctx.fill();

        ctx.fillStyle = 'rgba(255, 100, 100, 0.6)';
        ctx.beginPath(); ctx.ellipse(-24, 6, 5, 3, -Math.PI/8, 0, Math.PI*2); ctx.fill();
        ctx.beginPath(); ctx.ellipse(10, 8, 5, 3, 0, 0, Math.PI*2); ctx.fill();

        ctx.fillStyle = '#880e4f';
        ctx.beginPath();
        ctx.moveTo(-12, 10);
        ctx.quadraticCurveTo(-5, 20, 2, 10);
        ctx.fill();

        ctx.restore();
    }

    drawQuestionPing(ctx) {
        ctx.save();
        ctx.translate(0, 10);

        let pingGrad = ctx.createLinearGradient(0, -30, 0, 30);
        pingGrad.addColorStop(0, '#f1c40f');
        pingGrad.addColorStop(1, '#d35400');

        ctx.fillStyle = pingGrad;
        ctx.strokeStyle = '#333'; 
        ctx.lineWidth = 3;

        ctx.beginPath();
        ctx.moveTo(-15, -25);
        ctx.bezierCurveTo(-15, -45, 15, -45, 15, -25); 
        ctx.bezierCurveTo(15, -10, -5, -5, -5, 10);   
        ctx.lineTo(5, 10);                            
        ctx.bezierCurveTo(5, -10, 28, -15, 28, -25);  
        ctx.bezierCurveTo(28, -55, -28, -55, -28, -25); 
        ctx.lineTo(-15, -25);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(0, 18);
        ctx.lineTo(-10, 28);
        ctx.lineTo(0, 38);
        ctx.lineTo(10, 28);
        ctx.closePath();
        ctx.fill();
        ctx.stroke();

        ctx.restore();
    }
}

