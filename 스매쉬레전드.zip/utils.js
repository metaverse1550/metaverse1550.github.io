// ===== utils.js =====
// 범용 수학/유틸 함수 (게임 로직과 무관하게 재사용 가능)

function rand(min, max) { return Math.random() * (max - min) + min; }
function clamp(val, min, max) { return Math.max(min, Math.min(max, val)); }
function getDistance(x1, y1, x2, y2) { return Math.hypot(x2 - x1, y2 - y1); }
