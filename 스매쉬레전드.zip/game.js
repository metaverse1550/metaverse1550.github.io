// ===== game.js =====
// Game 클래스: 스코어/세트/서브/랠리 상태머신 + 렌더링(draw) + 판정
// updateAI()는 기존에 update() 안에 인라인으로 박혀있던 "싱글플레이 AI 상대 로직"을
// 동작 변경 없이 별도 메서드로만 뽑아낸 것 (나중에 mode-ai.js로 완전히 분리하기 쉽도록 만든 자리)

class Game {
    constructor() {
        this.p1 = new Character(-1, '#1e90ff'); 
        this.p2 = new Character(1, '#ff4757');
        this.birdie = new Shuttlecock(); 
        
        this.particles = []; 
        this.texts = []; 
        this.shockwaves = []; 
        this.emotions = [];
        
        this.state = STATE.MENU; 
        this.score = { p1: 0, p2: 0 }; 
        this.sets = { p1: 0, p2: 0 };
        this.server = this.p1; 
        this.playerSide = -1; 
        this.shakeTimer = 0; 
        this.msgTimer = 0; 
        this.netTick = 0;
        
        this.lastHitTime = Date.now();

        this.rematchState = {
            p1Request: false,
            p2Request: false,
            timer: 0,
            active: false,
            agreed: false
        };
    }
    
    // 🚀 [수정] 게임 시작 시 증강 시스템을 초기화하고 카드 3선택지 팝업을 바로 작동시킴
    startMatch() { 
        this.score = { p1: 0, p2: 0 }; 
        this.sets = { p1: 0, p2: 0 }; 
        this.playerSide = -1; 
        this.server = this.p1; 
        
        // 게임 세트를 먼저 시작한 후 바로 증강 선택 창을 띄움
        this.startSet(); 

        if (typeof AugmentManager !== 'undefined') {
            AugmentManager.init();
            AugmentManager.triggerSelection(); // 💥 시작하자마자 3선택지 똿!
        }
    }
    
    startSet() { 
        this.score = { p1: 0, p2: 0 }; 
        this.p1.reset(-1); 
        this.p2.reset(1); 
        this.readyServe(this.server); 
        
        const msgOverlay = document.getElementById('msg-overlay');
        if (msgOverlay) {
            msgOverlay.classList.remove('show'); 
        }
    }
    
    readyServe(serverChar) { 
        this.state = STATE.SERVE; 
        this.server = serverChar; 
        this.birdie.active = false; 
        
        let hx = serverChar.x + (serverChar.dir === -1 ? 25 : -25); 
        this.birdie.reset(hx, serverChar.y - 20); 
        
        this.p1.isSwinging = false; 
        this.p1.swingTimer = 0; 
        this.p1.swingType = ''; 
        this.p1.hitCooldown = 0; 
        this.p1.activeEmote = null; 
        this.p1.emoteTimer = 0;
        
        this.p2.isSwinging = false; 
        this.p2.swingTimer = 0; 
        this.p2.swingType = ''; 
        this.p2.hitCooldown = 0; 
        this.p2.activeEmote = null; 
        this.p2.emoteTimer = 0;
        
        this.lastHitTime = Date.now();
    }
    
    addScore(winner) { 
        this.state = STATE.SCORE_WAIT; 
        this.msgTimer = 160; 
        
        let msg = winner === this.p1 ? "P1 POINT!" : "P2 POINT!"; 
        let color = winner === this.p1 ? "#00f2fe" : "#ff4757"; 
        
        this.texts.push(new FloatingText(CW / 2, CH / 2, msg, color, 60)); 
        
        if (winner === this.p1) {
            this.score.p1++; 
        } else {
            this.score.p2++; 
        }
        
        this.server = winner; 
        
        if (typeof SoundEngine !== 'undefined' && SoundEngine.playScorePoint) {
            SoundEngine.playScorePoint(); 
        }
        
        broadcastData('score_sync', { 
            score: this.score, 
            serverSide: this.server === this.p1 ? 'p1' : 'p2' 
        }); 
        
        if (this.score.p1 >= 21 || this.score.p2 >= 21) { 
            this.handleSetEnd(winner); 
        } 
    }
    
    handleSetEnd(winner) { 
        this.state = STATE.SET_OVER; 
        this.msgTimer = 180; 
        
        if (winner === this.p1) { 
            this.sets.p1++; 
            if (typeof showUIMessage === 'function') showUIMessage("SET WIN (P1)!"); 
        } else { 
            this.sets.p2++; 
            if (typeof showUIMessage === 'function') showUIMessage("SET WIN (P2)!"); 
        } 
        
        broadcastData('set_end_sync', { 
            sets: this.sets, 
            state: this.state 
        }); 
    }
    
    checkHit(char) {
        if (this.state !== STATE.PLAYING && this.state !== STATE.SERVE) return;

        if (!char.isSwinging || char.hitCooldown > 0 || char.swingTimer > char.swingDuration * 0.75 || this.birdie.lastHitter === char) return;
        
        let hitbox = char.getHitBox();
        let dist = getDistance(hitbox.x, hitbox.y, this.birdie.x, this.birdie.y);
        
        if (dist < hitbox.r + this.birdie.radius) {
            this.birdie.lastHitter = char;
            this.state = STATE.PLAYING; 
            this.birdie.active = true; 
            char.hitCooldown = 20;
            this.birdie.freezeTicks = HIT_FREEZE_TICKS[char.swingType] || 12;
            this.birdie.shotType = char.swingType;
            
            let faceDir = char.dir === -1 ? 1 : -1;
            let sweetDist = getDistance(hitbox.sweetX, hitbox.sweetY, this.birdie.x, this.birdie.y);
            let isSweetSpot = sweetDist < hitbox.sweetR + this.birdie.radius;
            let speedMod = (char.swingType === 'smash' || char.swingType === 'drive' || char.swingType === 'mega') ? (isSweetSpot ? 1.1 : 0.8) : 1.0;
            let vx = 0, vy = 0, hitText = "", color = "#fff";
            this.birdie.isSmashShot = false; 
            this.birdie.smashTicks = 0;
            
            this.lastHitTime = Date.now();

            if (char.swingType === 'mega') {
                this.birdie.isSmashShot = true; 
                let force = 66 * char.hitPower * speedMod * 1.8; 
                vx = force * Math.cos(25 * Math.PI / 180) * faceDir; 
                vy = force * Math.sin(25 * Math.PI / 180); 
                this.birdie.maxSmashSpeed = Math.hypot(vx, vy);
                this.shockwaves.push(new SmashShockwave(this.birdie.x, this.birdie.y, '#ffd700', 2.2)); 
                
                if (typeof SoundEngine !== 'undefined' && SoundEngine.playMegaHit) SoundEngine.playMegaHit(); 
                
                hitText = "MEGA SHOT!"; 
                color = "#ffea00"; 
                this.shakeScreen(45); 
                this.spawnParticles(this.birdie.x, this.birdie.y, color, 60);
            } else if (char.swingType === 'smash') {
                let now = Date.now();
                if (now - char.lastSmashHitTime > 5000) {
                    char.smashStreak = 0; 
                }
                
                let decayMultiplier = Math.pow(0.91, char.smashStreak); 
                char.smashStreak++;
                char.lastSmashHitTime = now;

                this.birdie.isSmashShot = true; 
                let baseForce = 66 * char.hitPower * speedMod; 
                let force = baseForce * decayMultiplier; 

                vx = force * Math.cos(25 * Math.PI / 180) * faceDir; 
                vy = force * Math.sin(25 * Math.PI / 180); 
                this.birdie.maxSmashSpeed = Math.hypot(vx, vy);

                this.shockwaves.push(new SmashShockwave(this.birdie.x, this.birdie.y, '#ffffff', 1.0)); 
                
                if (typeof SoundEngine !== 'undefined' && SoundEngine.playSmashHit) SoundEngine.playSmashHit(); 

                if (char.smashStreak > 1) {
                    let percentVal = Math.round(decayMultiplier * 100);
                    hitText = `SMASH x${char.smashStreak} (${percentVal}%)`;
                } else {
                    hitText = isSweetSpot ? "PERFECT SMASH!" : "SMASH";
                }

                color = isSweetSpot ? "#ff0000" : "#ff4757"; 
                this.shakeScreen(isSweetSpot ? 25 : 15); 
                this.spawnParticles(this.birdie.x, this.birdie.y, color, isSweetSpot ? 30 : 20);
            } else {
                if (typeof SoundEngine !== 'undefined' && SoundEngine.playNormalHit) SoundEngine.playNormalHit();
                
                if (char.swingType === 'lob') { 
                    vy = -24; 
                    vx = ((char.dir === -1 ? COURT_RIGHT : COURT_LEFT) - this.birdie.x) * 0.019; 
                    hitText = "CLEAR"; 
                    color = "#2ed573"; 
                    this.spawnParticles(this.birdie.x, this.birdie.y, color, 10); 
                } else if (char.swingType === 'drop') { 
                    let dx = (NET_X + (char.dir === -1 ? 100 : -100)) - this.birdie.x; 
                    vy = (this.birdie.y < FLOOR_Y - NET_HEIGHT - 20) ? -2 : -9.5; 
                    vx = dx * 0.025; 
                    hitText = "DROP"; 
                    color = "#00cec9"; 
                    this.spawnParticles(this.birdie.x, this.birdie.y, color, 10); 
                } else if (char.swingType === 'serve') {
                    let targetLobVx = ((char.dir === -1 ? COURT_RIGHT : COURT_LEFT) - this.birdie.x) * 0.019;
                    let targetDriveVx = 26 * faceDir;
                    vx = (targetLobVx + targetDriveVx) / 2; 
                    vy = -14.1; 
                    hitText = "SERVE";
                    color = "#ffd700";
                    this.spawnParticles(this.birdie.x, this.birdie.y, color, 12);
                } else { 
                    vx = (26 * speedMod) * faceDir; 
                    vy = -3.28 * speedMod; 
                    hitText = isSweetSpot ? "PERFECT DRIVE!" : "DRIVE"; 
                    color = "#feca57"; 
                    this.spawnParticles(this.birdie.x, this.birdie.y, color, 10); 
                }
            }
            this.birdie.vx = vx; 
            this.birdie.vy = vy; 
            this.texts.push(new FloatingText(this.birdie.x, this.birdie.y - 30, hitText, color));
            
            broadcastData('hit_effect', { 
                x: this.birdie.x, 
                y: this.birdie.y, 
                hitText, 
                color, 
                type: char.swingType, 
                vx: this.birdie.vx, 
                vy: this.birdie.vy, 
                isSmashShot: this.birdie.isSmashShot, 
                maxSmashSpeed: this.birdie.maxSmashSpeed 
            });
        }
    }
    
    triggerRematch() {
        if (this.state !== STATE.PLAYING && this.state !== STATE.SERVE && this.state !== STATE.SCORE_WAIT) return;
        if (this.rematchState.agreed) return; 

        let mySide = (networkRole === 'host') ? 'p1' : 'p2';
        
        if (isLocalSinglePlayer) {
            this.handleRematchAgree();
            return;
        }

        if ((mySide === 'p1' && this.rematchState.p1Request) || (mySide === 'p2' && this.rematchState.p2Request)) return;

        if ((mySide === 'p1' && this.rematchState.p2Request) || (mySide === 'p2' && this.rematchState.p1Request)) {
            this.handleRematchAgree();
            broadcastData('rematch_agree', {});
        } else {
            this.rematchState[mySide + 'Request'] = true;
            this.rematchState.active = true;
            this.rematchState.timer = 150; 
            broadcastData('rematch_request', { side: mySide });
        }
    }

    handleRematchAgree() {
        this.rematchState.agreed = true;
        this.rematchState.timer = 60; 
        this.state = STATE.SCORE_WAIT; 
        if (typeof showUIMessage === 'function') showUIMessage("재경기 합의 완료!");
    }

    spawnEmotion(char, type) {
        this.emotions = this.emotions.filter(e => e.owner !== char);
        this.emotions.push(new EmotionBubble(char, type));
        if (typeof SoundEngine !== 'undefined' && SoundEngine.playFunnyEmotion) {
            SoundEngine.playFunnyEmotion();
        }
    }

    update() {
        if (this.state === STATE.MENU || this.state === STATE.MATCH_OVER) return;

        // 🚀 [추가] 증강 선택 창이 떠 있는 동안에는 물리 엔진 업데이트를 전부 일시정지(Pause) 시킨다!
        if (typeof AugmentManager !== 'undefined' && AugmentManager.showSelectionUI) {
            return; 
        }

        if (this.shakeTimer > 0) this.shakeTimer--;
        
        if (localMegaCooldown > 0) {
            let elapsed = Date.now() - lastMegaTriggerTime;
            localMegaCooldown = Math.max(0, 60000 - elapsed);
        }

        if (this.rematchState.active) {
            this.rematchState.timer--;
            if (this.rematchState.timer <= 0) {
                if (this.rematchState.agreed) {
                    this.rematchState.p1Request = false;
                    this.rematchState.p2Request = false;
                    this.rematchState.active = false;
                    this.rematchState.agreed = false;
                    this.readyServe(this.server); 
                    if (typeof showUIMessage === 'function') showUIMessage("서브 리셋");
                } else {
                    this.rematchState.p1Request = false;
                    this.rematchState.p2Request = false;
                    this.rematchState.active = false;
                }
            }
        }

        let myChar = (networkRole === 'host') ? this.p1 : this.p2;
        myChar.vx = 0; 
        
        if (networkRole === 'guest') { 
            if (keys.a) myChar.vx = myChar.speed; 
            if (keys.d) myChar.vx = -myChar.speed; 
        } else { 
            if (keys.a) myChar.vx = -myChar.speed; 
            if (keys.d) myChar.vx = myChar.speed; 
        }
        
        if (isJustPressed('w')) myChar.startJump(); 
        if (keys.w) myChar.holdJump();
        
        let swType = ''; 
        if (isJustPressed('ArrowUp')) swType = 'lob'; 
        else if (isJustPressed('ArrowDown')) swType = 'smash'; 
        
        if (isJustPressed('ArrowLeft')) swType = 'drop'; 
        else if (isJustPressed('ArrowRight')) swType = 'drive';
        
        if (swType) { 
            if (this.state === STATE.SERVE || this.state === STATE.PLAYING) {
                if (this.state === STATE.SERVE) {
                    swType = 'serve';
                }
                myChar.swing(swType); 
                if (networkRole === 'guest') broadcastData('guest_swing_input', { type: swType }); 
            }
        }
        
        this.updateAI();

        this.p1.update(); 
        this.p2.update();
        
        if (this.birdie.freezeTicks > 0 && this.birdie.shotType) { 
            let hitter = (this.birdie.x < NET_X) ? this.p1 : this.p2; 
            let color = SHOT_COLORS[this.birdie.shotType] || '#fff'; 
            let hitbox = hitter.getHitBox(); 
            this.particles.push(new DriftParticle(hitbox.x, hitbox.y, color, hitter.dir)); 
        }
        this.netTick++;

        if (this.netTick % NET_SYNC_RATE === 0) {
            broadcastData('player_pos', { 
                x: myChar.x, 
                y: myChar.y, 
                vy: myChar.vy, 
                isSwinging: myChar.isSwinging, 
                swingType: myChar.swingType,
                activeEmote: myChar.activeEmote,
                emoteTimer: myChar.emoteTimer
            });
        }

        if (networkRole === 'host') {
            this.birdie.update(); 
            this.checkHit(this.p1); 
            this.checkHit(this.p2);
            
            if (this.state === STATE.PLAYING && this.birdie.y > FLOOR_Y) {
                this.birdie.y = FLOOR_Y; 
                this.birdie.vx = 0; 
                this.birdie.vy = 0; 
                
                let pointWinner = (this.birdie.x < NET_X) ? this.p2 : this.p1;
                this.addScore(pointWinner);
            }
            if (this.netTick % NET_BALL_SYNC_RATE === 0) {
                broadcastData('ball_sync', { 
                    x: this.birdie.x, 
                    y: this.birdie.y, 
                    vx: this.birdie.vx, 
                    vy: this.birdie.vy, 
                    active: this.birdie.active, 
                    state: this.state, 
                    isSmashShot: this.birdie.isSmashShot, 
                    smashTicks: this.birdie.smashTicks, 
                    maxSmashSpeed: this.birdie.maxSmashSpeed, 
                    freezeTicks: this.birdie.freezeTicks, 
                    shotType: this.birdie.shotType 
                });
            }
        } else {
            this.birdie.update(); 
            if (this.state === STATE.PLAYING && this.birdie.y > FLOOR_Y) { 
                this.birdie.y = FLOOR_Y; 
                this.birdie.vy = -this.birdie.vy * 0.3; 
                this.birdie.vx *= 0.5; 
            }
        }
        
        for (let i = this.particles.length - 1; i >= 0; i--) { 
            this.particles[i].update(); 
            if (this.particles[i].life <= 0) this.particles.splice(i, 1); 
        }
        for (let i = this.texts.length - 1; i >= 0; i--) { 
            this.texts[i].update(); 
            if (this.texts[i].life <= 0) this.texts.splice(i, 1); 
        }
        for (let i = this.shockwaves.length - 1; i >= 0; i--) { 
            this.shockwaves[i].update(); 
            if (this.shockwaves[i].life <= 0) this.shockwaves.splice(i, 1); 
        }
        for (let i = this.emotions.length - 1; i >= 0; i--) { 
            this.emotions[i].update(); 
            if (this.emotions[i].life <= 0) this.emotions.splice(i, 1); 
        }
        
        if (this.msgTimer > 0) { 
            this.msgTimer--; 
            if (this.msgTimer <= 0) { 
                if (this.state === STATE.SCORE_WAIT) {
                    this.readyServe(this.server); 
                } else if (this.state === STATE.SET_OVER) { 
                    if (this.sets.p1 >= 2 || this.sets.p2 >= 2) { 
                        this.state = STATE.MATCH_OVER; 
                        if (typeof showMatchResult === 'function') showMatchResult(); 
                    } else { 
                        this.playerSide *= -1; 
                        this.startSet(); 
                    } 
                } 
            } 
        }
    }

    // AI(싱글플레이 상대) 로직 - update()에서 인라인으로 있던 부분을 그대로 분리한 것 (동작 동일)
    updateAI() {
        if (isLocalSinglePlayer) {
            let ai = this.p2;
            ai.vx = 0;
            
            if (this.state === STATE.SERVE && this.server === ai) {
                ai.swing('serve');
            } else if (this.state === STATE.PLAYING) {
                let targetX = this.birdie.x;
                if (this.birdie.x < NET_X) {
                    targetX = COURT_RIGHT - 180; 
                }
                
                let distToTarget = targetX - ai.x;
                if (Math.abs(distToTarget) > 15) {
                    ai.vx = Math.sign(distToTarget) * ai.speed * 0.72; 
                }
                
                if (this.birdie.x > NET_X && this.birdie.y < FLOOR_Y - 220 && Math.abs(this.birdie.x - ai.x) < 110) {
                    if (Math.random() < 0.12 && !ai.isJumping) ai.startJump();
                }
                
                let hitbox = ai.getHitBox();
                let distToBall = getDistance(hitbox.x, hitbox.y, this.birdie.x, this.birdie.y);
                if (distToBall < hitbox.r + this.birdie.radius) {
                    let randomShot = Math.random();
                    let shotType = 'drive';
                    if (ai.y < FLOOR_Y - ai.height - 30) {
                        shotType = 'smash'; 
                    } else if (this.birdie.x > CW - 240) {
                        shotType = 'lob'; 
                    } else if (randomShot < 0.35) {
                        shotType = 'drop';
                    } else if (randomShot < 0.7) {
                        shotType = 'lob';
                    }
                    ai.swing(shotType);
                }
            }
        }
    }

    draw() {
        ctx.clearRect(0, 0, CW, CH); 
        ctx.save(); 
        
        if (networkRole === 'guest') { 
            ctx.translate(CW, 0); 
            ctx.scale(-1, 1); 
        }
        if (this.shakeTimer > 0) { 
            ctx.translate(rand(-5, 5) * (this.shakeTimer / 15), rand(-5, 5) * (this.shakeTimer / 15)); 
        }
        
        let bgGrad = ctx.createLinearGradient(0, 0, 0, FLOOR_Y); 
        bgGrad.addColorStop(0, '#1a1a2e'); 
        bgGrad.addColorStop(1, '#16213e'); 
        ctx.fillStyle = bgGrad; 
        ctx.fillRect(0, 0, CW, CH);
        
        ctx.fillStyle = '#cf9963'; 
        ctx.fillRect(0, FLOOR_Y, CW, CH - FLOOR_Y); 
        ctx.fillStyle = '#fff'; 
        ctx.fillRect(50, FLOOR_Y, CW - 100, 5); 
        ctx.fillRect(NET_X - 2, FLOOR_Y, 4, 10); 
        ctx.fillStyle = 'rgba(0,0,0,0.2)'; 
        ctx.fillRect(0, FLOOR_Y + 5, CW, 15);
        
        ctx.strokeStyle = '#555'; 
        ctx.lineWidth = 10; 
        ctx.beginPath(); 
        ctx.moveTo(NET_X, FLOOR_Y); 
        ctx.lineTo(NET_X, FLOOR_Y - NET_HEIGHT); 
        ctx.stroke();
        
        ctx.fillStyle = 'rgba(255, 255, 255, 0.4)'; 
        ctx.fillRect(NET_X - 2, FLOOR_Y - NET_HEIGHT, 4, NET_HEIGHT); 
        ctx.fillStyle = '#fff'; 
        ctx.fillRect(NET_X - 4, FLOOR_Y - NET_HEIGHT, 8, 10);
        
        this.drawShadow(this.p1.x, FLOOR_Y, 30); 
        this.drawShadow(this.p2.x, FLOOR_Y, 30); 
        
        if (this.birdie.active || this.state === STATE.SERVE) {
            this.drawShadow(this.birdie.x, FLOOR_Y, 10 + (FLOOR_Y - this.birdie.y) * 0.02);
        }
        
        this.p1.draw(ctx); 
        this.p2.draw(ctx); 
        this.birdie.draw(ctx); 
        
        this.particles.forEach(p => p.draw(ctx)); 
        this.texts.forEach(t => t.draw(ctx)); 
        this.shockwaves.forEach(sw => sw.draw(ctx)); 
        this.emotions.forEach(e => e.draw(ctx));
        
        ctx.restore(); 
        this.drawHUD();

        // 🚀 [추가] 증강 선택 UI 렌더링 연동
        // (게임 화면의 오브젝트와 HUD를 다 그린 맨 마지막 위에 3장의 카드 레이어를 덮어 씌움)
        if (typeof AugmentManager !== 'undefined') {
            AugmentManager.drawSelectionUI(ctx);
        }

        // 🚀 [수정] 증강 모드일 때는 모바일 MEGA 버튼을 완전히 비활성화(숨김) 시킵니다.
        const touchMegaBtn = document.getElementById('touch-mega');
        if (touchMegaBtn) {
            if (typeof currentGameMode !== 'undefined' && currentGameMode === 'augment') {
                touchMegaBtn.style.display = 'none';
            } else {
                touchMegaBtn.style.display = 'flex'; // 기존 스타일 유지
                if (localMegaCooldown > 0) {
                    touchMegaBtn.classList.add('cooling');
                    touchMegaBtn.innerText = Math.ceil(localMegaCooldown / 1000) + "s";
                } else {
                    touchMegaBtn.classList.remove('cooling');
                    touchMegaBtn.innerText = "MEGA";
                }
            }
        }
    }
    
    drawShadow(x, y, radius) { 
        let safeRadius = Math.max(0, radius); 
        if (safeRadius === 0) return; 
        
        ctx.save(); 
        ctx.fillStyle = 'rgba(0,0,0,0.3)'; 
        ctx.beginPath(); 
        ctx.scale(1, 0.2); 
        ctx.arc(x, y / 0.2, safeRadius, 0, Math.PI * 2); 
        ctx.fill(); 
        ctx.restore(); 
    }
    
    drawHUD() {
        if (this.state === STATE.MENU) return; 
        
        let btnX = 30, btnY = 30, btnW = 140, btnH = 40;
        ctx.save();
        
        if (this.rematchState.agreed) {
            ctx.fillStyle = '#2ed573'; 
        } else if (this.rematchState.active) {
            ctx.fillStyle = '#f1c40f'; 
        } else {
            ctx.fillStyle = 'rgba(255, 255, 255, 0.2)'; 
        }

        ctx.beginPath(); 
        ctx.roundRect(btnX, btnY, btnW, btnH, 10); 
        ctx.fill();
        
        ctx.fillStyle = '#fff'; 
        ctx.font = "bold 16px 'Noto Sans KR', sans-serif"; 
        ctx.textAlign = "center";
        
        let btnText = "🔄 재경기 요청";
        if (this.rematchState.agreed) {
            btnText = "✅ 승인 완료!";
        } else if (this.rematchState.active) {
            let mySide = (networkRole === 'host') ? 'p1' : 'p2';
            if (this.rematchState[mySide + 'Request']) {
                btnText = `⏳ 동의 대기중 (${Math.ceil(this.rematchState.timer / 30)})`;
            } else {
                btnText = "❗ 상대 재경기 요청";
            }
        }
        ctx.fillText(btnText, btnX + btnW / 2, btnY + 26);
        ctx.restore();

        ctx.fillStyle = 'rgba(0, 0, 0, 0.6)'; 
        ctx.beginPath(); 
        ctx.roundRect(CW / 2 - 200, 20, 400, 80, 15); 
        ctx.fill(); 
        
        ctx.font = "bold 40px 'Black Han Sans', sans-serif"; 
        ctx.textAlign = "center";
        
        ctx.fillStyle = (networkRole === 'guest') ? '#ff4757' : '#00f2fe'; 
        ctx.fillText(this.score.p1, CW / 2 - 100, 75); 
        
        ctx.fillStyle = (networkRole === 'guest') ? '#00f2fe' : '#ff4757'; 
        ctx.fillText(this.score.p2, CW / 2 + 100, 75);
        
        ctx.fillStyle = '#fff'; 
        ctx.font = "bold 20px 'Noto Sans KR', sans-serif"; 
        ctx.fillText(`SET ${this.sets.p1 + this.sets.p2 + 1}`, CW / 2, 45);
        
        let drawSetCircle = (x, y, won) => { 
            ctx.beginPath(); 
            ctx.arc(x, y, 8, 0, Math.PI * 2); 
            ctx.fillStyle = won ? '#ffd700' : 'rgba(255,255,255,0.2)'; 
            ctx.fill(); 
        };
        drawSetCircle(CW / 2 - 60, 65, this.sets.p1 >= 1); 
        drawSetCircle(CW / 2 - 40, 65, this.sets.p1 >= 2); 
        drawSetCircle(CW / 2 + 40, 65, this.sets.p2 >= 1); 
        drawSetCircle(CW / 2 + 60, 65, this.sets.p2 >= 2);

        // 🚀 [수정] 현재 모드가 증강 모드('augment')일 때는 캔버스에 쿨타임 바를 아예 그리지 않도록 차단!
        if (typeof currentGameMode !== 'undefined' && currentGameMode === 'augment') {
            return;
        }

        let barW = 260;
        let barH = 14;
        let barX = CW / 2 - barW / 2;
        let barY = 125;

        ctx.save();
        ctx.fillStyle = 'rgba(15, 23, 42, 0.75)';
        ctx.beginPath();
        ctx.roundRect(barX - 10, barY - 10, barW + 20, barH + 18, 10);
        ctx.fill();

        if (localMegaCooldown > 0) {
            let progress = (60000 - localMegaCooldown) / 60000;
            ctx.fillStyle = 'rgba(255, 255, 255, 0.15)';
            ctx.beginPath();
            ctx.roundRect(barX, barY, barW, barH, 7);
            ctx.fill();

            ctx.fillStyle = '#ffaa00';
            ctx.beginPath();
            ctx.roundRect(barX, barY, barW * progress, barH, 7);
            ctx.fill();

            ctx.fillStyle = '#ffcc00';
            ctx.font = "bold 13px 'Noto Sans KR', sans-serif";
            ctx.textAlign = 'center';
            ctx.fillText(`MEGA SHOT COOLDOWN: ${Math.ceil(localMegaCooldown / 1000)}s`, CW / 2, barY - 12);
        } else {
            ctx.fillStyle = '#fff200';
            ctx.beginPath();
            ctx.roundRect(barX, barY, barW, barH, 7);
            ctx.fill();

            let alpha = 0.5 + 0.5 * Math.sin(Date.now() * 0.007);
            ctx.shadowColor = '#fff200';
            ctx.shadowBlur = 10;
            ctx.fillStyle = `rgba(255, 242, 0, ${alpha})`;
            ctx.font = "bold 14px 'Black Han Sans', sans-serif";
            ctx.textAlign = 'center';
            ctx.fillText(`⚡ [R] MEGA SHOT READY ⚡`, CW / 2, barY - 14);
        }
        ctx.restore();
    }
    
    shakeScreen(amount) { 
        this.shakeTimer = amount; 
    }
    
    spawnParticles(x, y, color, count) { 
        for (let i = 0; i < count; i++) { 
            this.particles.push(new Particle(x, y, color)); 
        } 
    }
}