// ===== sound.js =====
// SoundEngine: 오디오 재생 전담 (WebAudio 기반 효과음)
// 게임 로직을 전혀 모르는 독립적인 모듈

const SoundEngine = {
    ctx: null,
    init() {
        if (!this.ctx) {
            this.ctx = new (window.AudioContext || window.webkitAudioContext)();
        }
    },
    playNormalHit() {
        this.init();
        if (!this.ctx) return;
        let osc = this.ctx.createOscillator();
        let gain = this.ctx.createGain();
        osc.connect(gain); gain.connect(this.ctx.destination);

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(320, this.ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(800, this.ctx.currentTime + 0.03); 

        gain.gain.setValueAtTime(0.4, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.08); 

        osc.start(); osc.stop(this.ctx.currentTime + 0.08);
    },
    playSmashHit() {
        this.init();
        if (!this.ctx) return;
        
        let now = this.ctx.currentTime;

        let osc = this.ctx.createOscillator();
        let gainNode = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(180, now);
        osc.frequency.exponentialRampToValueAtTime(600, now + 0.04);
        gainNode.gain.setValueAtTime(0.8, now);
        gainNode.gain.exponentialRampToValueAtTime(0.01, now + 0.15);
        osc.connect(gainNode); gainNode.connect(this.ctx.destination);
        osc.start(); osc.stop(now + 0.15);

        let bufferSize = this.ctx.sampleRate * 0.12; 
        let buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        let data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) { data[i] = Math.random() * 2 - 1; }

        let noise = this.ctx.createBufferSource();
        noise.buffer = buffer;
        let noiseFilter = this.ctx.createBiquadFilter();
        noiseFilter.type = 'bandpass'; 
        noiseFilter.frequency.setValueAtTime(1000, now);
        noiseFilter.frequency.exponentialRampToValueAtTime(2500, now + 0.08);

        let noiseGain = this.ctx.createGain();
        noiseGain.gain.setValueAtTime(0.3, now);
        noiseGain.gain.exponentialRampToValueAtTime(0.01, now + 0.12);

        noise.connect(noiseFilter); noiseFilter.connect(noiseGain); noiseGain.connect(this.ctx.destination);
        noise.start(); noise.stop(now + 0.12);
    },
    playMegaAttemptSound() {
        this.init();
        if (!this.ctx) return;
        let now = this.ctx.currentTime;
        let osc = this.ctx.createOscillator();
        let gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(150, now);
        osc.frequency.exponentialRampToValueAtTime(1200, now + 0.3);
        gain.gain.setValueAtTime(0.3, now);
        gain.gain.exponentialRampToValueAtTime(0.01, now + 0.3);
        osc.connect(gain);
        gain.connect(this.ctx.destination);
        osc.start(); osc.stop(now + 0.3);
    },
    playMegaHit() {
        this.init();
        if (!this.ctx) return;
        let now = this.ctx.currentTime;

        let osc1 = this.ctx.createOscillator();
        let gain1 = this.ctx.createGain();
        osc1.type = 'sawtooth';
        osc1.frequency.setValueAtTime(380, now);
        osc1.frequency.exponentialRampToValueAtTime(35, now + 0.45);
        gain1.gain.setValueAtTime(0.95, now);
        gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.6);
        
        let osc2 = this.ctx.createOscillator();
        let gain2 = this.ctx.createGain();
        osc2.type = 'triangle';
        osc2.frequency.setValueAtTime(1300, now);
        osc2.frequency.exponentialRampToValueAtTime(250, now + 0.18);
        gain2.gain.setValueAtTime(0.65, now);
        gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

        let bufferSize = this.ctx.sampleRate * 0.4; 
        let buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        let data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) { data[i] = Math.random() * 2 - 1; }

        let noise = this.ctx.createBufferSource();
        noise.buffer = buffer;
        let noiseFilter = this.ctx.createBiquadFilter();
        noiseFilter.type = 'bandpass'; 
        noiseFilter.frequency.setValueAtTime(900, now);
        noiseFilter.frequency.exponentialRampToValueAtTime(80, now + 0.35);

        let noiseGain = this.ctx.createGain();
        noiseGain.gain.setValueAtTime(0.85, now);
        noiseGain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);

        let waveShaper = this.ctx.createWaveShaper();
        const makeDistCurve = (amount) => {
            let k = amount, n = 44100, curve = new Float32Array(n), deg = Math.PI / 180;
            for (let i = 0; i < n; ++i) {
                let x = (i * 2) / n - 1;
                curve[i] = (3 + k) * x * 22 * deg / (Math.PI + k * Math.abs(x));
            }
            return curve;
        };
        waveShaper.curve = makeDistCurve(110);
        waveShaper.oversample = '4x';

        osc1.connect(waveShaper);
        osc2.connect(waveShaper);
        waveShaper.connect(gain1);
        gain1.connect(this.ctx.destination);

        noise.connect(noiseFilter);
        noiseFilter.connect(noiseGain);
        noiseGain.connect(this.ctx.destination);

        osc1.start(); osc1.stop(now + 0.6);
        osc2.start(); osc2.stop(now + 0.25);
        noise.start(); noise.stop(now + 0.4);
    },
    playFunnyEmotion() {
        this.init();
        if (!this.ctx) return;
        let now = this.ctx.currentTime;

        // 첫 번째 뿅 (피치가 아주 빠르게 솟구치는 사인파)
        let osc1 = this.ctx.createOscillator();
        let gain1 = this.ctx.createGain();
        osc1.type = 'sine';
        osc1.frequency.setValueAtTime(220, now);
        osc1.frequency.exponentialRampToValueAtTime(700, now + 0.07);
        gain1.gain.setValueAtTime(0.2, now);
        gain1.gain.exponentialRampToValueAtTime(0.01, now + 0.07);
        osc1.connect(gain1); gain1.connect(this.ctx.destination);
        osc1.start(); osc1.stop(now + 0.07);

        // 두 번째 뽀옹 (직후에 피치가 아래로 미끄러지는 우스꽝스러운 트라이앵글파)
        let osc2 = this.ctx.createOscillator();
        let gain2 = this.ctx.createGain();
        osc2.type = 'triangle';
        osc2.frequency.setValueAtTime(520, now + 0.05);
        osc2.frequency.exponentialRampToValueAtTime(140, now + 0.22);
        gain2.gain.setValueAtTime(0.18, now + 0.05);
        gain2.gain.exponentialRampToValueAtTime(0.01, now + 0.22);
        osc2.connect(gain2); gain2.connect(this.ctx.destination);
        osc2.start(now + 0.05); osc2.stop(now + 0.22);
    },
    playScorePoint() {
        this.init();
        if (!this.ctx) return;
        let now = this.ctx.currentTime;
        
        let playTone = (freq, delay, duration) => {
            let osc = this.ctx.createOscillator();
            let gain = this.ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, now + delay);
            gain.gain.setValueAtTime(0.25, now + delay);
            gain.gain.exponentialRampToValueAtTime(0.005, now + delay + duration);
            osc.connect(gain); gain.connect(this.ctx.destination);
            osc.start(now + delay); osc.stop(now + delay + duration);
        };

        playTone(523.25, 0, 0.15);     
        playTone(659.25, 0.06, 0.15);  
        playTone(783.99, 0.12, 0.35);  
    }
};
