// ===== augments.js =====
// 증강 모드(Augmented Mode) 전용 데이터, 선택 UI 및 상태 관리 시스템

const AUGMENT_DATABASE = [
    // Normal (N) - 총 확률 가중치: 50% (각 16.6%)
    { id: "double_jump", name: "더블 점프", rarity: "N", weight: 16.6, description: "공중에서 점프를 한 번 더 할 수 있습니다." },
    { id: "fast_walk", name: "가벼운 발걸음", rarity: "N", weight: 16.6, description: "이동 속도가 15% 증가합니다." },
    { id: "wide_racket", name: "자석 라켓", rarity: "N", weight: 16.8, description: "라켓의 타격 범위가 15% 넓어집니다." },
    
    // Rare (R) - 총 확률 가중치: 30% (각 10%)
    { id: "quick_swing", name: "신속한 스윙", rarity: "R", weight: 10.0, description: "스윙 후 딜레이가 25% 감소합니다." },
    { id: "high_jump", name: "경량화 슈즈", rarity: "R", weight: 10.0, description: "점프 높이가 25% 증가합니다." },
    { id: "dash_master", name: "대시 마스터", rarity: "R", weight: 10.0, description: "방향키를 빠르게 두 번 누르면 대시합니다." },
    
    // Super Rare (SR) - 총 확률 가중치: 15% (각 7.5%)
    { id: "mirror_shield", name: "반사 장벽", rarity: "SR", weight: 7.5, description: "네트 근처에 감속 장벽을 생성합니다." },
    { id: "wind_rider", name: "바람의 인도", rarity: "SR", weight: 7.5, description: "내가 치는 셔틀콕이 급격히 가속됩니다." },
    
    // Specially Super Rare (SSR) - 총 확률 가중치: 5% (각 2.5%)
    { id: "time_stop", name: "시간 왜곡", rarity: "SSR", weight: 2.5, description: "상대 타격 시 상대방을 0.5초간 감속시킵니다." },
    { id: "phoenix_feather", name: "불사조의 깃털", rarity: "SSR", weight: 2.5, description: "실점 직전 0.5초간 슬로우 모션이 적용됩니다." }
];

// 가중치 기반 랜덤 뽑기
function getRandomAugment() {
    const totalWeight = AUGMENT_DATABASE.reduce((sum, aug) => sum + aug.weight, 0);
    let randomNum = Math.random() * totalWeight;
    
    for (let aug of AUGMENT_DATABASE) {
        if (randomNum < aug.weight) {
            return aug;
        }
        randomNum -= aug.weight;
    }
    return AUGMENT_DATABASE[0];
}

const AugmentManager = {
    isActive: false,         // 증강 모드 활성화 여부
    showSelectionUI: false,  // 3택1 UI 창을 띄울지 여부
    choices: [],            // 화면에 띄운 무작위 3가지 증강 후보
    hoveredIndex: -1,       // 마우스 마우스오버된 카드의 인덱스 (0, 1, 2)

    player1Augments: [],    // 플레이어 1 획득 증강
    player2Augments: [],    // 플레이어 2 획득 증강

    // 카드 UI 좌표 계산용 (1280x720 기준)
    cardWidth: 260,
    cardHeight: 380,
    cardY: 180,
    cardXCoords: [180, 510, 840], // 3개 카드가 배치될 X 좌표들

    init() {
        // 💡 [추가] 현재 게임 모드가 증강('augment') 모드가 아닐 때는 증강 매니저를 활성화하지 않습니다.
        if (typeof currentGameMode !== 'undefined' && currentGameMode !== 'augment') {
            this.isActive = false;
            this.showSelectionUI = false;
            this.player1Augments = [];
            this.player2Augments = [];
            console.log("🚫 [AugmentManager] 증강 모드가 아니므로 비활성화 상태 유지");
            return;
        }

        this.isActive = true;
        this.player1Augments = [];
        this.player2Augments = [];
        this.showSelectionUI = false;
        this.choices = [];
        this.hoveredIndex = -1;
        console.log("🚀 [AugmentManager] 초기화 완료");
    },

    // 1단계: 게임 시작 시 3선택지 팝업 트리거
    triggerSelection() {
        // 💡 [추가] 증강 모드가 아니거나 비활성화 상태일 때는 절대로 선택창을 띄우지 않습니다.
        if (!this.isActive || (typeof currentGameMode !== 'undefined' && currentGameMode !== 'augment')) {
            this.showSelectionUI = false;
            return;
        }

        this.showSelectionUI = true;
        this.choices = [];
        
        // 중복 없이 3개의 증강을 후보로 뽑기
        while (this.choices.length < 3) {
            const candidate = getRandomAugment();
            if (!this.choices.some(c => c.id === candidate.id)) {
                this.choices.push(candidate);
            }
        }
        console.log("🎁 증강 선택창 활성화! 후보 3개:", this.choices);
        
        // 마우스 및 터치 클릭 감지 이벤트 등록
        this.registerClickEvents();
    },

    // 2단계: 플레이어가 선택 완료했을 때 처리
    selectAugment(index) {
        if (index < 0 || index >= this.choices.length) return;
        
        const selected = this.choices[index];
        this.player1Augments.push(selected);
        this.showSelectionUI = false; // UI 닫기
        
        console.log(`✅ [선택 완료] 플레이어 1이 [${selected.name}]을(를) 장착했습니다.`);

        // 💥 AI(P2)에게도 공평하게 하나 무작위로 쥐여주기
        const p2Aug = getRandomAugment();
        this.player2Augments.push(p2Aug);
        console.log(`🤖 [AI 증강] AI가 [${p2Aug.name}]을(를) 장착했습니다.`);

        // 게임이 멈춰있었다면 다시 흐르게 만듭니다. (game.js 측에서 제어 가능)
        if (typeof isGamePaused !== 'undefined') {
            isGamePaused = false; 
        }
    },

    // 3단계: 캔버스 위에 3가지 카드 렌더링하기
    drawSelectionUI(ctx) {
        if (!this.showSelectionUI) return;

        // 배경 어둡게 블러 처리 느낌 내기
        ctx.fillStyle = "rgba(0, 0, 0, 0.75)";
        ctx.fillRect(0, 0, ctx.canvas.width, ctx.canvas.height);

        // 상단 타이틀
        ctx.save();
        ctx.font = "bold 32px 'Black Han Sans', sans-serif";
        ctx.fillStyle = "#ffa502";
        ctx.textAlign = "center";
        ctx.fillText("증강 선택 (Augment Choose)", ctx.canvas.width / 2, 90);
        
        ctx.font = "18px 'Noto Sans KR', sans-serif";
        ctx.fillStyle = "#ffffff";
        ctx.fillText("남은 라운드를 지배할 영구적인 패시브 능력을 선택하세요.", ctx.canvas.width / 2, 130);

        // 카드 3개 그리기
        for (let i = 0; i < this.choices.length; i++) {
            const card = this.choices[i];
            const x = this.cardXCoords[i];
            const isHovered = (this.hoveredIndex === i);

            // 카드 영역 효과 (마우스 오버 시 떠오르거나 테두리가 밝아짐)
            const cy = isHovered ? this.cardY - 15 : this.cardY;
            const cardColor = this.getRarityColor(card.rarity);

            // 카드 그림자 및 배경
            ctx.shadowBlur = isHovered ? 25 : 10;
            ctx.shadowColor = cardColor;
            ctx.fillStyle = isHovered ? "#1e272e" : "#2f3640";
            
            // 둥근 사각형 그리기 흉내
            ctx.beginPath();
            ctx.roundRect ? ctx.roundRect(x, cy, this.cardWidth, this.cardHeight, 15) : ctx.rect(x, cy, this.cardWidth, this.cardHeight);
            ctx.fill();

            // 그림자 초기화
            ctx.shadowBlur = 0;

            // 카드 테두리
            ctx.strokeStyle = cardColor;
            ctx.lineWidth = isHovered ? 4 : 2;
            ctx.stroke();

            // 등급 텍스트 배지
            ctx.font = "bold 20px 'Black Han Sans', sans-serif";
            ctx.fillStyle = cardColor;
            ctx.textAlign = "center";
            ctx.fillText(`[ ${card.rarity} ]`, x + this.cardWidth / 2, cy + 50);

            // 증강 이름
            ctx.font = "bold 22px 'Noto Sans KR', sans-serif";
            ctx.fillStyle = "#ffffff";
            ctx.fillText(card.name, x + this.cardWidth / 2, cy + 110);

            // 가로 구분선
            ctx.strokeStyle = "rgba(255,255,255,0.1)";
            ctx.lineWidth = 1;
            ctx.beginPath();
            ctx.moveTo(x + 30, cy + 150);
            ctx.lineTo(x + this.cardWidth - 30, cy + 150);
            ctx.stroke();

            // 증강 설명문 (여러 줄 대응)
            ctx.font = "14px 'Noto Sans KR', sans-serif";
            ctx.fillStyle = "#ced6e0";
            this.wrapText(ctx, card.description, x + this.cardWidth / 2, cy + 190, this.cardWidth - 40, 24);

            // 선택 가이드 버블 (마우스 올렸을 때만 나옴)
            if (isHovered) {
                ctx.fillStyle = cardColor;
                ctx.font = "bold 15px 'Noto Sans KR', sans-serif";
                ctx.fillText("터치하여 장착!", x + this.cardWidth / 2, cy + 340);
            }
        }
        ctx.restore();
    },

    // 4단계: 입력 이벤트 등록 (마우스 움직임 및 클릭)
    registerClickEvents() {
        const canvas = document.getElementById("gameCanvas");
        if (!canvas) return;

        // 중복 등록 방지
        if (this.eventsRegistered) return;
        this.eventsRegistered = true;

        // 마우스 좌표 구하기 헬퍼 함수
        const getMousePos = (evt) => {
            const rect = canvas.getBoundingClientRect();
            // 화면 렌더 크기와 캔버스 원본 해상도(1280x720) 맵핑 연산
            return {
                x: (evt.clientX - rect.left) * (canvas.width / rect.width),
                y: (evt.clientY - rect.top) * (canvas.height / rect.height)
            };
        };

        // 1) 마우스 움직임 감지 (호버 효과용)
        canvas.addEventListener("mousemove", (e) => {
            if (!this.showSelectionUI) return;
            const pos = getMousePos(e);
            this.hoveredIndex = this.checkCardUnderMouse(pos.x, pos.y);
        });

        // 2) 클릭 감지 (선택 완료용)
        canvas.addEventListener("click", (e) => {
            if (!this.showSelectionUI) return;
            const pos = getMousePos(e);
            const index = this.checkCardUnderMouse(pos.x, pos.y);
            if (index !== -1) {
                this.selectAugment(index);
            }
        });

        // 3) 모바일 터치 대응
        canvas.addEventListener("touchstart", (e) => {
            if (!this.showSelectionUI) return;
            const touch = e.touches[0];
            const pos = getMousePos(touch);
            const index = this.checkCardUnderMouse(pos.x, pos.y);
            if (index !== -1) {
                this.selectAugment(index);
            }
        });
    },

    // 좌표값으로 카드 인덱스 체크하는 함수
    checkCardUnderMouse(mx, my) {
        for (let i = 0; i < this.cardXCoords.length; i++) {
            const x = this.cardXCoords[i];
            if (mx >= x && mx <= x + this.cardWidth &&
                my >= this.cardY && my <= this.cardY + this.cardHeight) {
                return i;
            }
        }
        return -1;
    },

    // 등급별 고유 색상
    getRarityColor(rarity) {
        switch (rarity) {
            case "N": return "#2ed573";   // 초록
            case "R": return "#1e90ff";   // 파랑
            case "SR": return "#9c88ff";  // 보라
            case "SSR": return "#ffa502"; // 황금
            default: return "#ffffff";
        }
    },

    // 글자 줄바꿈 함수
    wrapText(ctx, text, x, y, maxWidth, lineHeight) {
        const words = text.split('');
        let line = '';
        let currentY = y;

        for (let n = 0; n < words.length; n++) {
            let testLine = line + words[n];
            let metrics = ctx.measureText(testLine);
            let testWidth = metrics.width;
            if (testWidth > maxWidth && n > 0) {
                ctx.fillText(line, x, currentY);
                line = words[n];
                currentY += lineHeight;
            } else {
                line = testLine;
            }
        }
        ctx.fillText(line, x, currentY);
    }
};