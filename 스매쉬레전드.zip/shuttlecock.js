// ===== shuttlecock.js =====
// Shuttlecock 클래스: 셔틀콕 물리(포물선, 드래그, 궤적) - 모드(싱글/멀티) 상관없이 공통

class Shuttlecock {
    constructor() { this.reset(CW/2, 200); this.radius = 8; this.trail = []; this.isSmashShot = false; this.smashTicks = 0; this.maxSmashSpeed = 0; this.freezeTicks = 0; this.shotType = ''; this.lastHitter = null; }
    reset(x, y) {
        this.x = x; this.y = y; this.vx = 0; this.vy = 0;
        this.active = false; this.trail = []; this.rotation = 0;
        this.isSmashShot = false; this.smashTicks = 0; this.maxSmashSpeed = 0;
        this.freezeTicks = 0; this.shotType = ''; this.lastHitter = null;
    }
    update() {
        if (game.state === STATE.SERVE) {
            let currentServer = game.server;
            let hx = currentServer.x + (currentServer.dir === -1 ? 25 : -25);
            this.x = hx; 
            this.y = currentServer.y - 30;
            this.vx = 0;
            this.vy = 0;
            return;
        }

        if (!this.active) return;

        if (this.freezeTicks > 0) {
            this.freezeTicks--;
            return; 
        }

        if (this.isSmashShot) {
            this.smashTicks++;
            let currentDrag = 0.88; 
            
            if (this.smashTicks <= 4) {
                this.vy += GRAVITY * 0.1;
                this.vx *= 0.999;
                this.vy *= 0.999;
            } else {
                let currentSpeed = Math.hypot(this.vx, this.vy);
                let minSpeed = this.maxSmashSpeed * 0.10;

                if (currentSpeed * currentDrag > minSpeed) {
                    this.vx *= currentDrag;
                    this.vy *= currentDrag;
                } else {
                    if (currentSpeed > 0) {
                        let ratio = minSpeed / currentSpeed;
                        this.vx *= ratio;
                        this.vy *= ratio;
                    }
                }
            }
        } else {
            this.vy += GRAVITY;
            let drag = (this.shotType === 'drive') ? 0.994 : 0.987;
            this.vx *= drag;
            this.vy *= drag;
        }

        let oldX = this.x;
        let oldY = this.y;

        this.x += this.vx; 
        this.y += this.vy;
        this.rotation = Math.atan2(this.vy, this.vx);

        let netHalfWidth = 5;

        let crossedNet = (oldX < NET_X && this.x >= NET_X) || (oldX > NET_X && this.x <= NET_X);

        if (crossedNet && Math.abs(this.vx) > 0) {
            let t = (NET_X - oldX) / this.vx; 
            let interceptY = oldY + this.vy * t; 
            
            if (interceptY + this.radius > FLOOR_Y - NET_HEIGHT) {
                this.vx *= -0.5;
                this.x = oldX < NET_X ? NET_X - netHalfWidth - this.radius : NET_X + netHalfWidth + this.radius;
            }
        } else if (Math.abs(this.x - NET_X) < netHalfWidth + this.radius && this.y + this.radius > FLOOR_Y - NET_HEIGHT) {
            if (this.y < FLOOR_Y - NET_HEIGHT + 8 && this.vy > 0) { 
                this.vy *= -0.6; 
            } else { 
                this.vx *= -0.5; 
                this.x = this.x < NET_X ? NET_X - netHalfWidth - this.radius : NET_X + netHalfWidth + this.radius; 
            }
        }

        if (this.x < this.radius) {
            this.x = this.radius;
            this.vx *= -0.7; 
        } else if (this.x > CW - this.radius) {
            this.x = CW - this.radius;
            this.vx *= -0.7;
        }

        this.trail.push({x: this.x, y: this.y});
        if (this.trail.length > 8) this.trail.shift();
    }
    draw(ctx) {
        if (!this.active && game.state !== STATE.SERVE) return;
        if (this.trail.length > 1) {
            const TRAIL_COLORS = {
                smash: 'rgba(255, 40, 40, 0.85)',
                mega: 'rgba(255, 230, 0, 0.9)',
                lob: 'rgba(46, 213, 115, 0.7)',
                drop: 'rgba(0, 206, 201, 0.7)',
                drive: 'rgba(254, 202, 87, 0.7)',
                serve: 'rgba(255, 215, 0, 0.7)'
            };
            ctx.beginPath(); ctx.moveTo(this.trail[0].x, this.trail[0].y);
            for(let i=1; i<this.trail.length; i++) { ctx.lineTo(this.trail[i].x, this.trail[i].y); }
            ctx.strokeStyle = TRAIL_COLORS[this.shotType] || 'rgba(255, 255, 255, 0.4)'; 
            ctx.lineWidth = (this.isSmashShot || this.shotType === 'mega') ? 8 : 4; 
            ctx.stroke();
        }
        ctx.save(); ctx.translate(this.x, this.y); ctx.rotate(this.rotation + Math.PI/2);
        ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(-8, -15); ctx.lineTo(8, -15); ctx.closePath(); ctx.fill(); ctx.strokeStyle = '#ddd'; ctx.stroke();
        ctx.fillStyle = (this.isSmashShot || this.shotType === 'mega') ? '#ff1111' : '#ffbaba'; ctx.beginPath(); ctx.arc(0, 0, 6, 0, Math.PI * 2); ctx.fill(); ctx.strokeStyle = '#000'; ctx.stroke();
        ctx.restore();
    }
}
