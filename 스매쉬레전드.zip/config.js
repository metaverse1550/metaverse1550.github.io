// ===== config.js =====
// 전역 상수 / 설정값 / 네트워크·게임 상태 변수 모음
// (Supabase 접속정보, 캔버스 크기, 물리상수, 상태(STATE) enum, 샷 관련 상수표 등)
// 다른 모든 파일보다 먼저 로드되어야 함

const SUPABASE_URL = "https://rxhdzwlymxlcmgibkqaw.supabase.co";
const SUPABASE_KEY = "sb_publishable_MrCEPb2jUVbfxDZ0YosWAQ_zncJkz_f";
const sbClient = window.supabase ? window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY) : null;

const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const CW = canvas.width;
const CH = canvas.height;

const GRAVITY = 0.55;
const DRAG = 0.985;
const FLOOR_Y = 620;
const NET_X = CW / 2;
const NET_HEIGHT = 95; 
const COURT_LEFT = 100;
const COURT_RIGHT = CW - 100;

const STATE = { MENU: 0, SERVE: 1, PLAYING: 2, SCORE_WAIT: 3, SET_OVER: 4, MATCH_OVER: 5 };
const NET_SYNC_RATE = 2; 
const NET_BALL_SYNC_RATE = 6; 

let gameSession = null;
let networkRole = null; 
let isConnected = false;
let isLocalSinglePlayer = false; 

let localMegaCooldown = 0; 
let lastMegaTriggerTime = 0;

let opRematchTimerId = null;
let isAgreed = false;


// 샷/타격 관련 상수표 (원래 Shuttlecock 클래스 뒤에 있던 것을 config로 이동)
const SWING_DURATIONS = { smash: 20, mega: 20, lob: 18, drop: 12, drive: 8, serve: 15 };
const HIT_FREEZE_TICKS = { smash: 18, mega: 24, lob: 9, drop: 9, drive: 6, serve: 8 };
const SHOT_COLORS = {
    smash: '#ff4757', 
    mega: '#ffea00',
    lob: '#2ed573',   
    drop: '#00cec9',  
    drive: '#feca57',
    serve: '#ffd700'
};
