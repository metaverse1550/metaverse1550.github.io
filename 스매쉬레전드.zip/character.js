// ===== character.js =====
// Character 클래스: 이동/점프/스윙/히트박스 등 캐릭터 자체 동작만 담당
// (AI 판단 로직은 여기 없음 - game.js의 Game.updateAI()에 있음, 아래 설명 참고)

class Character {
    constructor(side, color) {
        this.width = 40; this.height = 130;
        this.x = (side === -1) ? COURT_LEFT + 200 : COURT_RIGHT - 200;
        this.y = FLOOR_Y - this.height;
        this.vx = 0; this.vy = 0; this.dir = side;
        this.isSwinging = false; this.swingTimer = 0; this.swingDuration = 12; this.swingType = '';
        this.legAngle = 0; this.color = color; this.hitCooldown = 0;
        
        this.activeEmote = null; 
        this.emoteTimer = 0;

        this.speed = 13.5;
        this.hitPower = 1.63;
        this.hitRange = 150; 

        this.isJumping = false;
        this.jumpHoldTicks = 0;
        this.maxJumpHoldTicks = 14; 

        this.smashStreak = 0;
        this.lastSmashHitTime = 0;
    }
    reset(side) {
        this.dir = side;
        this.x = (side === -1) ? COURT_LEFT + 200 : COURT_RIGHT - 200;
        this.y = FLOOR_Y - this.height; this.vx = 0; this.vy = 0; this.isSwinging = false; this.swingTimer = 0;
        this.isJumping = false;
        this.activeEmote = null;
        this.emoteTimer = 0;
        this.smashStreak = 0;
        this.lastSmashHitTime = 0;
    }
    update() {
        if (typeof game !== 'undefined' && game.birdie && game.birdie.freezeTicks > 0) {
            return;
        }

        if (this.activeEmote !== null) {
            this.emoteTimer++;
            
            let isMyChar = (this === game.p1 && networkRole === 'host') || (this === game.p2 && networkRole === 'guest');
            if (isMyChar) {
                let isMoving = keys.a || keys.d || keys.w || this.isSwinging || this.y < FLOOR_Y - this.height - 5;
                if (isMoving) {
                    this.activeEmote = null;
                    this.emoteTimer = 0;
                    if (typeof broadcastData === 'function') {
                        broadcastData('player_emote', { emote: null });
                    }
                }
            } else {
                if (Math.abs(this.vx) > 0.1 || this.isSwinging || this.y < FLOOR_Y - this.height - 5) {
                    this.activeEmote = null;
                    this.emoteTimer = 0;
                }
            }
        }

        if (this.activeEmote === 3) {
            this.y = FLOOR_Y - 45; 
            this.vy = 0;
        } else {
            this.vy += GRAVITY; this.y += this.vy;
            if (this.y >= FLOOR_Y - this.height) { 
                this.y = FLOOR_Y - this.height; 
                this.vy = 0; 
                this.isJumping = false; 
            }
            if (this.activeEmote === null && this.y > FLOOR_Y - this.height) {
                this.y = FLOOR_Y - this.height;
            }
        }

        this.x += this.vx;
        if (Math.abs(this.vx) > 0.1 && this.y >= FLOOR_Y - this.height) { this.legAngle += 0.25; } else { this.legAngle = 0; }
        if (this.isSwinging) {
            this.swingTimer++;
            if (this.swingTimer >= this.swingDuration) { this.isSwinging = false; this.swingTimer = 0; }
        }
        if (this.hitCooldown > 0) this.hitCooldown--;
        
        if (this.dir === -1) { 
            this.x = clamp(this.x, 20, NET_X - 30); 
        } else { 
            this.x = clamp(this.x, NET_X + 30, CW - 20); 
        }
    }
    swing(type) {
        if (!this.isSwinging && this.hitCooldown === 0) {
            this.activeEmote = null; 
            this.isSwinging = true; this.swingTimer = 0; this.swingType = type;
            this.swingDuration = SWING_DURATIONS[type] || 12;
        }
    }
    startJump() {
        if (this.isSwinging) return;
        this.activeEmote = null; 
        if (this.y >= FLOOR_Y - this.height - 5) { 
            this.vy = -13.5; 
            this.isJumping = true; 
            this.jumpHoldTicks = 0; 
        }
    }
    holdJump() {
        if (this.isJumping && this.jumpHoldTicks < this.maxJumpHoldTicks) {
            this.vy -= 0.8; 
            this.jumpHoldTicks++;
        }
    }
    stopJump() {
        if (this.isJumping) {
            this.isJumping = false;
            if (this.vy < -4) { 
                this.vy *= 0.45; 
            }
        }
    }

    getAngles() {
        let isAirborne = this.y < FLOOR_Y - this.height - 5;
        let sA = Math.PI / 3, eA = -Math.PI / 6, wA = -Math.PI / 6;
        let torso = 0, crouch = 0, lunge = 0;

        if (isAirborne && !this.isSwinging) { sA = Math.PI; eA = 0; wA = -Math.PI / 6; }

        if (this.activeEmote !== null) {
            let time = this.emoteTimer;
            if (this.activeEmote === 1) {
                crouch = Math.sin(time * 0.4) * 20;
                torso = Math.sin(time * 0.4) * 0.15;
                sA = Math.PI * 1.1 + Math.sin(time * 0.3) * 0.2;
                eA = Math.sin(time * 0.3) * 0.4;
                wA = -Math.PI / 6;
            } else if (this.activeEmote === 2) {
                torso = -0.8;
                crouch = 25;
                lunge = Math.sin(time * 0.7) * 25;
                sA = Math.PI / 4;
                eA = -Math.PI / 6;
            } else if (this.activeEmote === 3) {
                torso = Math.PI / 2.1;
                crouch = 0;
                lunge = 0;
                sA = -Math.PI / 2;
                eA = Math.PI / 2;
                wA = 0;
            }
        } else if (this.isSwinging) {
            let p = this.swingTimer / this.swingDuration;

            if (this.swingType === 'smash' || this.swingType === 'mega') {
                if (p < 0.35) {
                    let t = p / 0.35; let te = 1 - Math.pow(1 - t, 2);
                    sA = Math.PI * 1.15 * (1 - te) + (-Math.PI / 5) * te;
                    eA = (Math.PI * 0.5) * te;
                    wA = (Math.PI / 2.3) * te;
                    torso = -0.4 * te;
                    crouch = 20 * Math.sin(t * Math.PI * 0.9);
                } else {
                    let t = (p - 0.35) / 0.65; let te = 1 - Math.pow(1 - t, 4);
                    sA = (-Math.PI / 5) * (1 - te) + (Math.PI * 0.72) * te;
                    eA = (Math.PI * 0.5) * (1 - te) + (-Math.PI * 0.18) * te;
                    wA = (Math.PI / 2.3) * (1 - te) + (-Math.PI / 3) * te;
                    torso = -0.4 * (1 - te) + 0.5 * te;
                    crouch = 20 * (1 - te) * 0.5;
                    lunge = 28 * te;
                }
            } else if (this.swingType === 'lob') {
                if (p < 0.3) {
                    let t = p / 0.3;
                    sA = Math.PI * (1 - t) + (-Math.PI / 3.2) * t;
                    eA = (Math.PI * 0.7) * t;
                    wA = (-Math.PI / 6) * (1 - t) + (Math.PI / 2.2) * t;
                    torso = -0.3 * t;
                    crouch = 6 * t;
                } else {
                    let t = (p - 0.3) / 0.7; let te = 1 - Math.pow(1 - t, 3);
                    sA = (-Math.PI / 3.2) * (1 - te) + (Math.PI * 0.65) * te;
                    eA = (Math.PI * 0.7) * (1 - te) + (-Math.PI * 0.1) * te;
                    wA = (Math.PI / 2.2) * (1 - te) + (-Math.PI / 5) * te;
                    torso = -0.3 * (1 - te) + 0.22 * te;
                    crouch = 6 * (1 - te);
                    lunge = 12 * te;
                }
            } else if (this.swingType === 'drop') {
                let t = 1 - Math.pow(1 - p, 2);
                sA = Math.PI * 0.55 * (1 - t) + (Math.PI * 0.22) * t;
                eA = (-Math.PI / 7) * (1 - t) + (Math.PI / 10) * t;
                wA = (-Math.PI / 8) * (1 - t) + (Math.PI / 2.6) * t;
                torso = 0.08 * t;
                crouch = 9 * Math.sin(p * Math.PI);
            } else if (this.swingType === 'drive') {
                let te = 1 - Math.pow(1 - p, 5);
                sA = Math.PI * 0.25 * (1 - te) + (-Math.PI * 0.28) * te;
                eA = (-Math.PI / 5) * (1 - te) + (Math.PI / 6) * te;
                wA = (Math.PI / 5) * te;
                torso = 0.06 * te;
                lunge = 7 * te;
            } else if (this.swingType === 'serve') {
                let te = 1 - Math.pow(1 - p, 3);
                sA = (Math.PI * 0.6) * (1 - te) + (-Math.PI * 0.1) * te;
                eA = (Math.PI * 0.3) * (1 - te) + (Math.PI * 0.4) * te;
                wA = (-Math.PI / 4) * (1 - te) + (Math.PI / 3) * te;
                torso = -0.1 * (1 - te) + 0.15 * te;
                crouch = 5 * Math.sin(p * Math.PI);
                lunge = 8 * te;
            }
        }
        return { sA, eA, wA, torso, crouch, lunge };
    }

    getHitBox() {
        let faceDir = this.dir === -1 ? 1 : -1;
        let angles = this.getAngles();

        let shoulderX = this.x + faceDir * (angles.lunge || 0) * 0.4;
        let shoulderY = this.y + 30 + (angles.crouch || 0) * 0.3;
        
        let sweetSpotX = shoulderX + Math.cos((angles.torso + angles.sA) * faceDir) * 15 + Math.cos((angles.torso + angles.sA + angles.eA) * faceDir) * 50;
        let sweetSpotY = shoulderY + Math.sin((angles.torso + angles.sA) * faceDir) * 15 + Math.sin((angles.torso + angles.sA + angles.eA) * faceDir) * 50;

        return { 
            x: this.x, y: this.y + 60, r: 150, 
            sweetX: sweetSpotX, sweetY: sweetSpotY, sweetR: 70 
        }; 
    }

    draw(ctx) {
        ctx.save(); ctx.translate(this.x, this.y);
        let faceDir = this.dir === -1 ? 1 : -1;

        if (this.activeEmote === 2) {
            faceDir = -faceDir;
        }

        ctx.scale(faceDir, 1);
        let angles = this.getAngles();
        let crouch = angles.crouch || 0;
        let lunge = angles.lunge || 0;
        let torso = angles.torso || 0;
        ctx.save(); ctx.translate(lunge * 0.4, crouch * 0.5);

        if (this.isSwinging && this.swingType === 'mega') {
            ctx.shadowBlur = 30;
            ctx.shadowColor = '#ffd700';
        }

        ctx.fillStyle = this.color;

        ctx.beginPath(); ctx.roundRect(-10, 20 + crouch * 0.3, 20, 60 - crouch * 0.3, 10); ctx.fill();

        ctx.save(); ctx.translate(0, 5 + crouch * 0.3); ctx.rotate(torso * 0.5);
        ctx.fillStyle = '#ffdbac'; ctx.beginPath(); ctx.arc(0, 0, 15, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#000'; ctx.beginPath(); ctx.arc(5, -3, 3, 0, Math.PI * 2); ctx.fill(); ctx.restore();

        ctx.strokeStyle = '#333'; ctx.lineWidth = 6; ctx.lineCap = 'round';
        let isAirborne = this.y < FLOOR_Y - this.height - 5;
        let hipY = 75 + crouch * 0.3;

        if (this.activeEmote === 3) {
            let legDangle = Math.sin(this.emoteTimer * 0.15) * 15;
            ctx.beginPath(); ctx.moveTo(-5, hipY); ctx.lineTo(-30, hipY + 10); ctx.stroke(); 
            ctx.beginPath(); ctx.moveTo(5, hipY); ctx.lineTo(15 + legDangle, hipY - 20); ctx.stroke(); 
        } else if (isAirborne && !this.isSwinging) {
            ctx.beginPath(); ctx.moveTo(-5, hipY); ctx.lineTo(-20, 100); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(5, hipY); ctx.lineTo(-10, 105); ctx.stroke();
        } else if (isAirborne && this.isSwinging) {
            ctx.beginPath(); ctx.moveTo(-5, hipY); ctx.lineTo(10 + lunge, 125); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(5, hipY); ctx.lineTo(25 + lunge * 0.6, 120); ctx.stroke();
        } else if (this.isSwinging && lunge > 0.5) {
            ctx.beginPath(); ctx.moveTo(-5, hipY); ctx.lineTo(-5 + lunge * 1.3, 128); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(5, hipY); ctx.lineTo(5 - lunge * 0.5, 132); ctx.stroke();
        } else if (this.activeEmote === 1) {
            let danceLeg = Math.sin(this.emoteTimer * 0.4) * 15;
            ctx.beginPath(); ctx.moveTo(-5, hipY); ctx.lineTo(-15 + danceLeg, 130); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(5, hipY); ctx.lineTo(15 - danceLeg, 130); ctx.stroke();
        } else {
            let legAnim = Math.sin(this.legAngle) * 22; 
            ctx.beginPath(); ctx.moveTo(-5, hipY); ctx.lineTo(-5 - legAnim, 130); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(5, hipY); ctx.lineTo(5 + legAnim, 130); ctx.stroke();
        }

        ctx.save(); ctx.translate(0, 30 + crouch * 0.3);
        ctx.rotate(torso);
        ctx.rotate(angles.sA); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(15, 0); ctx.strokeStyle = '#ffdbac'; ctx.lineWidth = 6; ctx.lineCap = 'round'; ctx.stroke();
        ctx.translate(15, 0); ctx.rotate(angles.eA); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(15, 0); ctx.stroke();
        ctx.translate(15, 0); ctx.rotate(angles.wA); ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(25, 0); ctx.strokeStyle = '#777'; ctx.lineWidth = 3; ctx.stroke();
        ctx.beginPath(); ctx.ellipse(37, 0, 12, 18, 0, 0, Math.PI * 2); ctx.strokeStyle = '#fff'; ctx.lineWidth = 3; ctx.stroke();
        ctx.fillStyle = 'rgba(255,255,255,0.3)'; ctx.fill();
        ctx.restore();
        ctx.restore(); ctx.restore();
    }
}
