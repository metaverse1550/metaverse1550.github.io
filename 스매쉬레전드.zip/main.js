// ===== main.js =====
// 진입점(Entry Point): Game 인스턴스 생성 + 게임 루프 시작 + 싱글플레이 시작 함수 + HUD 버튼 클릭 처리
// (기존에 통짜 HTML에서 맨 아래쪽 <script> 태그에 있던 "실행부"에 해당하는 부분)

const game = new Game();

// ----- 싱글 플레이(AI 대전) 시작 -----
function initLocalSinglePlayer() {
    networkRole = 'host';       // 항상 host 시점으로 그림/조작 (p1 = 나)
    isLocalSinglePlayer = true;
    isConnected = false;

    SoundEngine.init();

    document.getElementById('menu-ui').classList.add('hidden');
    document.getElementById('room-status').innerText = '';

    game.startMatch();
}

// ----- HUD 위 "재경기 요청" 버튼(캔버스에 직접 그려짐)을 위한 클릭 처리 -----
// game.js drawHUD()의 btnX=30, btnY=30, btnW=140, btnH=40 좌표와 반드시 일치해야 함
canvas.addEventListener('click', (e) => {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const clickX = (e.clientX - rect.left) * scaleX;
    const clickY = (e.clientY - rect.top) * scaleY;

    const btnX = 30, btnY = 30, btnW = 140, btnH = 40;
    if (clickX >= btnX && clickX <= btnX + btnW && clickY >= btnY && clickY <= btnY + btnH) {
        if (game.state === STATE.PLAYING || game.state === STATE.SERVE || game.state === STATE.SCORE_WAIT) {
            game.triggerRematch();
        }
    }
});

// ----- 메인 게임 루프 -----
function gameLoop() {
    game.update();
    game.draw();
    requestAnimationFrame(gameLoop);
}
requestAnimationFrame(gameLoop);
