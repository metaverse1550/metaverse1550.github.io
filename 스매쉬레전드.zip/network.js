// ===== network.js =====
// Supabase Realtime 기반 멀티플레이 통신 (Host-Guest 데이터 동기화)
// 게임 로직과 완전히 독립적으로 뗄 수 있는 부분

function initMultimulti(role) {
    const roomStatusEl = document.getElementById('room-status');
    const roomName = document.getElementById('room-input').value.trim();

    if (!sbClient) { 
        roomStatusEl.innerHTML = "<span style='color: #ff4757;'>⚠️ Supabase가 초기화되지 않았습니다. API 설정을 확인하세요.</span>"; 
        return; 
    }
    if (!roomName) { 
        roomStatusEl.innerHTML = "<span style='color: #ff4757;'>⚠️ 방 이름을 먼저 입력해 주세요!</span>"; 
        return; 
    }

    networkRole = role; 
    isLocalSinglePlayer = false;
    roomStatusEl.innerText = `${roomName}번방 동기화 연결 중...`; 
    SoundEngine.init();
    gameSession = sbClient.channel(roomName, { config: { broadcast: { self: false, ack: false } } });
    gameSession
    .on('broadcast', { event: 'player_pos' }, ({ payload }) => { 
        let targetChar = (networkRole === 'host') ? game.p2 : game.p1; 
        targetChar.x = payload.x; 
        targetChar.y = payload.y; 
        targetChar.vy = payload.vy; 
        targetChar.isSwinging = payload.isSwinging; 
        targetChar.swingType = payload.swingType; 
        targetChar.activeEmote = payload.activeEmote;
        targetChar.emoteTimer = payload.emoteTimer;
    })
    .on('broadcast', { event: 'guest_swing_input' }, ({ payload }) => { if (networkRole === 'host') game.p2.swing(payload.type); })
    .on('broadcast', { event: 'player_emote' }, ({ payload }) => {
        let targetChar = (networkRole === 'host') ? game.p2 : game.p1;
        targetChar.activeEmote = payload.emote;
        targetChar.emoteTimer = 0;
    })
    .on('broadcast', { event: 'player_emotion' }, ({ payload }) => {
        let targetChar = (networkRole === 'host') ? game.p2 : game.p1;
        game.spawnEmotion(targetChar, payload.type);
    })
    .on('broadcast', { event: 'rematch_request' }, ({ payload }) => {
        if (payload.side !== ((networkRole === 'host') ? 'p1' : 'p2')) {
            game.rematchState[payload.side + 'Request'] = true;
            if (!game.rematchState.active) {
                game.rematchState.active = true;
                game.rematchState.timer = 150; 
            }
        }
    })
    .on('broadcast', { event: 'rematch_agree' }, ({ payload }) => {
        game.handleRematchAgree();
    })
    .on('broadcast', { event: 'ball_sync' }, ({ payload }) => {
        if (networkRole === 'guest') {
            if (game.state !== STATE.SERVE) {
                if (payload.freezeTicks > 0) { game.birdie.x = payload.x; game.birdie.y = payload.y; } 
                else { if (getDistance(game.birdie.x, game.birdie.y, payload.x, payload.y) > 20) { game.birdie.x = payload.x; game.birdie.y = payload.y; } else { game.birdie.x = game.birdie.x * 0.4 + payload.x * 0.6; game.birdie.y = game.birdie.y * 0.4 + payload.y * 0.6; } }
            }
            game.birdie.vx = payload.vx; game.birdie.vy = payload.vy; game.birdie.active = payload.active; game.state = payload.state; game.birdie.isSmashShot = payload.isSmashShot; game.birdie.smashTicks = payload.smashTicks; game.birdie.maxSmashSpeed = payload.maxSmashSpeed; game.birdie.freezeTicks = payload.freezeTicks; game.birdie.shotType = payload.shotType;
        }
    })
    .on('broadcast', { event: 'score_sync' }, ({ payload }) => { if (networkRole === 'guest') { game.score = payload.score; game.server = payload.serverSide === 'p1' ? game.p1 : game.p2; SoundEngine.playScorePoint(); } })
    .on('broadcast', { event: 'set_end_sync' }, ({ payload }) => { if (networkRole === 'guest') { game.sets = payload.sets; game.state = payload.state; let isP2Win = game.sets.p2 > game.sets.p1; showUIMessage(isP2Win ? "SET WIN (P2)!" : "SET WIN (P1)!"); } })
    .on('broadcast', { event: 'hit_effect' }, ({ payload }) => {
        if (networkRole === 'guest') {
            game.texts.push(new FloatingText(payload.x, payload.y - 30, payload.hitText, payload.color)); game.spawnParticles(payload.x, payload.y, payload.color, payload.type === 'smash' ? 20 : (payload.type === 'mega' ? 60 : 10));
            if (payload.type === 'smash') { SoundEngine.playSmashHit(); game.shakeScreen(15); game.shockwaves.push(new SmashShockwave(payload.x, payload.y, '#ffffff', 1.0)); } 
            else if (payload.type === 'mega') { SoundEngine.playMegaHit(); game.shakeScreen(45); game.shockwaves.push(new SmashShockwave(payload.x, payload.y, '#ffd700', 2.2)); } 
            else { SoundEngine.playNormalHit(); }
            game.birdie.x = payload.x; game.birdie.y = payload.y; game.birdie.vx = payload.vx; game.birdie.vy = payload.vy; game.birdie.active = true; game.birdie.isSmashShot = payload.isSmashShot; game.birdie.smashTicks = 0; game.birdie.maxSmashSpeed = payload.maxSmashSpeed; game.state = STATE.PLAYING; game.birdie.shotType = payload.type; game.birdie.freezeTicks = HIT_FREEZE_TICKS[payload.type] || 12;
        }
    })
    .subscribe((status) => { if (status === 'SUBSCRIBED') { isConnected = true; document.getElementById('menu-ui').classList.add('hidden'); game.state = STATE.SERVE; game.startMatch(); } });
}

function broadcastData(event, payload) { if (isConnected && gameSession) send({ type: 'broadcast', event, payload }); }
function send(packet) { if (gameSession) gameSession.send(packet); }
function showUIMessage(text) { let msgEl = document.getElementById('msg-overlay'); if (networkRole === 'guest') { if (text.includes("P1")) text = text.replace("P1", "상대방"); else if (text.includes("P2")) text = text.replace("P2", "나"); } else { if (text.includes("P1")) text = text.replace("P1", "나"); else if (text.includes("P2")) text = text.replace("P2", "상대방"); } msgEl.innerText = text; msgEl.classList.add('show'); setTimeout(() => { msgEl.classList.remove('show'); }, 2000); }
function showMatchResult() { let isP1Win = game.sets.p1 >= 2; showUIMessage((networkRole === 'guest') ? (isP1Win ? "MATCH OVER: 상대방 WIN!" : "MATCH OVER: 나 WIN!") : (isP1Win ? "MATCH OVER: 나 WIN!" : "MATCH OVER: 상대방 WIN!")); }
